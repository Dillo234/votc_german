# Voices of the Court mod files

This is the mod files for the Voices of the Court ck3 mod.

Main repository: [github.com/Vocies-of-the-Court/VOTC](https://github.com/Vocies-of-the-Court/VOTC)
